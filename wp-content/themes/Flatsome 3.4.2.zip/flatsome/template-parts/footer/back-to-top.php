<a href="#top" class="back-to-top button invert plain is-outline hide-for-medium icon circle fixed bottom z-1" id="top-link"><?php echo get_flatsome_icon('icon-angle-up'); ?></a>
