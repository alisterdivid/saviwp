<li class="html header-button-1">
	<div class="header-button">
	<?php 
		echo do_shortcode('[button text="'.flatsome_option('header_button_1').'" link="'.flatsome_option('header_button_1_link').'" target="'.flatsome_option('header_button_1_link_target').'" radius="'.flatsome_option('header_button_1_radius').'" size="'.flatsome_option('header_button_1_size').'" color="'.flatsome_option('header_button_1_color').'" depth="'.flatsome_option('header_button_1_depth').'"  depth_hover="'.flatsome_option('header_button_1_depth_hover').'" style="'.flatsome_option('header_button_1_style').'"]');
	?>
	</div>
</li>


