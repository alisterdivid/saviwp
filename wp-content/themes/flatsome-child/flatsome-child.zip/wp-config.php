<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://codex.wordpress.org/Editing_wp-config.php

 *

 * @package WordPress

 */



// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define('DB_NAME', 'digitale_saviwp');



/** MySQL database username */

define('DB_USER', 'digitale_saviwp');



/** MySQL database password */

define('DB_PASSWORD', ',bsgw%Gvu.]E');
//define('DB_PASSWORD', '');


/** MySQL hostname */

define('DB_HOST', 'localhost');



/** Database Charset to use in creating database tables. */

define('DB_CHARSET', 'utf8mb4');



/** The Database Collate type. Don't change this if in doubt. */

define('DB_COLLATE', '');



/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define('AUTH_KEY',         ';QQ~p=yBQpr}WE.{j$v?y8bTP<[cK$k-UK0FuNISL01 `9zThVo@|yV)4bm}#m*)');

define('SECURE_AUTH_KEY',  '5$9b@r$I%do%Y]vF1UTpt!]W{yBh)+1D` *j!#%&F1aHO,,iX#?<3jryQ!CtN=Dz');

define('LOGGED_IN_KEY',    ';vAYO:##w:0DX:bP M(%Pt)?Z[HYC!kBIM7N#9hFlT9;P2pkA<UQeOZh6&yZIe>M');

define('NONCE_KEY',        '&sLV`&gT*Z8l7ON)N]y@[=?yML$l2I4u2qU)4}vV&m&Mq=+Z3*aD`I6[[a^vM9Xx');

define('AUTH_SALT',        'G$MVxKE@MR?^48mk#)kTh fo4Nf2+O-vn[DAx`=*Q!_r#>^Bh5IjEIIZ7 oDR;B*');

define('SECURE_AUTH_SALT', '0GE[G&[nL)J-vc iv9~~9giq$Dm8d<myXP8Ezx|-7)zP7~xye1`j8D!|L%h7Ft[n');

define('LOGGED_IN_SALT',   '3$3].+OuA)DE}8JKDe`}d6o~N(rqoM o*5o0)%w(u-zGu8dd*nbI_d;`GP265imI');

define('NONCE_SALT',       ' 2sYfBTI(#b6lnkvx.[[y%}s$#0]#UmU~^x)GT/9>QAt4-DMw(aL5ppx2X##nWr#');



/**#@-*/



/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix  = 'wp_';



/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the Codex.

 *

 * @link https://codex.wordpress.org/Debugging_in_WordPress

 */

define('WP_DEBUG', false);
//define( 'WP_MEMORY_LIMIT', '256M' );


/* That's all, stop editing! Happy blogging. */



/** Absolute path to the WordPress directory. */

if ( !defined('ABSPATH') )

	define('ABSPATH', dirname(__FILE__) . '/');



/** Sets up WordPress vars and included files. */

require_once(ABSPATH . 'wp-settings.php');

